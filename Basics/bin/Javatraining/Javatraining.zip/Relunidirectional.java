package Javatraining;

public class Relunidirectional {

}
