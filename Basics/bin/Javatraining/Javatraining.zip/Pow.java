package Javatraining;

import java.util.Scanner;

public class Pow {
	public static void main(String[] args) {
		Scanner scanner = new Scanner(System.in);
		double b =Math.pow(100,200)%3;
		System.out.println(b);
	}
}
