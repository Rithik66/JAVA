package Javatraining;

import java.util.*;
class Person{
    private String name,mobile,email,city;
    Person(){}
    Person(String n,String m,String e,String c){
        name=n;
        mobile=m;
        email=e;
        city=c;
    }
    public void personDisplay(){
        System.out.println(name+" "+mobile+" "+email+" "+city);
    }
}
class Employee{
    private int id,salary;
    private String dept;
    Employee(String n,String m,String e,String c,int i,String d,int s){
        Person p = new Person(n,m,e,c);
        id=i;
        dept=d;
        salary=s;
    }
    public void employeeDisplay(Person p){
        p.personDisplay();
        System.out.println(id+" "+salary+" "+dept);
    }
}
class Main{
    public static void main(String[]args){
        Scanner scanner = new Scanner(System.in);
        String name = scanner.nextLine();
        String mobile = scanner.nextLine();
        String email = scanner.nextLine();
        String city = scanner.nextLine();
        int id = scanner.nextInt();
        scanner.nextLine();
        String dept = scanner.nextLine();
        int salary = scanner.nextInt();
        Employee emp = new Employee(name,mobile,email,city,id,dept,salary);
        Person p = new Person();
        emp.employeeDisplay(p);
    }
}