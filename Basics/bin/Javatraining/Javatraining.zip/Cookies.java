package Javatraining;

import java.util.*;

public class Cookies {
	public static void main(String[] args) {
		Scanner scanner = new Scanner(System.in);
		int a = scanner.nextInt();
		scanner.nextLine();
		String s=scanner.nextLine();
		String[] s1 =s.split("\\s");
		int length = 0;
		for(String ans:s1) {
			length++;
		}
		if(length==a) {
		int check=0,max=0,len=0;
		for (String ans:s1) {
			if(ans.equals("cookie")) check++;
			else check=0;
			len++;
			if(len==a && check==1) max=2;
			else max=Math.max(check, max);
			}
		if(max>1) System.out.println("No");
		else System.out.println("Yes");
		}
	}
}
