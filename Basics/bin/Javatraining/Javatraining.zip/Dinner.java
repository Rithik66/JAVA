package Javatraining;

import java.util.Scanner;

public class Dinner {
	public static void main(String[] args) {
		Scanner scanner = new Scanner(System.in);
		int pink = scanner.nextInt();
		int green = scanner.nextInt();
		int red = scanner.nextInt();
		int orange = scanner.nextInt();
		int amount = scanner.nextInt();
		int p=0,g=0,r=0,o=0;
		for(int i =0;i<10;i++) {
			
		}
	}
}
