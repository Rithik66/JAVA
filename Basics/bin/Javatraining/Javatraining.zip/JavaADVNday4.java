package Javatraining;

public class JavaADVNday4 {
	public static void main(String[] args) {
		
	}
}