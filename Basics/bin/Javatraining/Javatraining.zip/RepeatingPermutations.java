package Javatraining;

import java.util.Scanner;

public class RepeatingPermutations {
	public static void main(String[] args) {
		Scanner scanner = new Scanner(System.in);
		int a = new Scanenr
	}
}
